<?php
spl_autoload_register(function($class_name){
include "classes/".$class_name.".php";
});

error_reporting(0);
$newspaper = new Newspaper(); 



$all_sub_cat= $newspaper->getSubCategoryData(); 

 
?>
<?php
//Single page code
 
$post_id = $_GET['pid'];
$all_single = $newspaper->getSingleData($post_id);

?>

<!-----------------------
     Category page
------------------------->

<?php
$cat_id = $_GET['cid'];
$sub_cat_id = $_GET['scid'];
$all_categories = $newspaper->getcategoriesData($cat_id);
$all_categories3 = $newspaper->getcategoriesData3($cat_id);
$all_categories4 = $newspaper->getcategoriesData4($cat_id);

?>

<!-----------------------
     Sub Category page
------------------------->
<?php
$sub_cat_id = $_GET['scid'];

?>
<!-----------------------
     Index page
------------------------->

<?php 
$allNews = $newspaper->getAllNewsData();
?>

<?php 
$allNews1 = $newspaper->getAllNewsData1();
?>

<?php 
$allNews2 = $newspaper->getAllNewsData2();
?>

<?php 
$nationalNews = $newspaper->getNationalNewsData();
?>

<?php 
$internationalNews = $newspaper->getInternationalNewsData();
?>


<!-- Tab-title -->

<?php 

//Tab-1
$TabTitleGoodNews1 = $newspaper->getTabTitleGoodNews1();
$TabTitleGoodNews2 = $newspaper->getTabTitleGoodNews2();
$TabTitleGoodNews3 = $newspaper->getTabTitleGoodNews3();
$TabTitleGoodNews4 = $newspaper->getTabTitleGoodNews4();
$TabTitleGoodNews5 = $newspaper->getTabTitleGoodNews5();


//Tab-2
 $TabTitleReadNews1 = $newspaper->getTabTitleReadNews1();
 $TabTitleReadNews2 = $newspaper->getTabTitleReadNews2();
 $TabTitleReadNews3 = $newspaper->getTabTitleReadNews3();
 $TabTitleReadNews4 = $newspaper->getTabTitleReadNews4();
 $TabTitleReadNews5 = $newspaper->getTabTitleReadNews5();


//Tab-3
$TabTitleFeaturedNews1 = $newspaper->getTabTitleFeaturedNews1();
$TabTitleFeaturedNews2 = $newspaper->getTabTitleFeaturedNews2();
$TabTitleFeaturedNews3 = $newspaper->getTabTitleFeaturedNews3();
$TabTitleFeaturedNews4 = $newspaper->getTabTitleFeaturedNews4();
$TabTitleFeaturedNews5 = $newspaper->getTabTitleFeaturedNews5();
?>

<!-- Katun News -->
<?php 
$KatunNews = $newspaper->getKatunNews();
?>
