<?php 
include("inc/query-code.php");
include("header.php"); 
?>

<!-- Banner Ads -->
<div class="container">
  <div class="content ptb-25">
    <div class="row banner-ad-970">
      <img src="assets/image/ad1.png"> 
    </div><!-- row -->
  </div><!-- content ptb-25 -->

<!-- Main content -->   
	  <div class="section-1">
      <div class="row">
       <?php while($row = mysqli_fetch_assoc($allNews1)) { ?>
        <div class="column-25">
          <div class="news">
            <a href="single.php?pid=<?php echo $row['post_id']?>">
              <div class="news-image" style="background-image: url('admin/uploads/image/<?php echo $row['image'];?>')"></div>
               <h3><?php echo $row['title']; ?></h3>
              <p><?php echo substr($row['description'],0,350); ?>...</p>
            </a>
         </div><!-- news  -->    
       </div><!-- column-25 -->
       <?php } ?> 
   </div><!-- row -->
 </div><!-- section-1 -->

<div class="content ptb-25">	
 <div class="section-2">
 	  <div class="row">
       <div class="column-75">
          <div class="row">
         <?php while($row = mysqli_fetch_assoc($allNews2)) { ?>
          <div class="column-25">
          <div class="news">
          <a href="single.php?pid=<?php echo $row['post_id']?>">
          <div class="news-image" style="background-image: url('admin/uploads/image/<?php echo $row['image'];?>')"></div>
          <h3><?php echo $row['title']; ?></h3>
        </a>
      </div><!-- news  -->    
     </div><!-- column-25 -->
   <?php } ?>
  </div><!-- row -->
 </div><!-- ptb-25 -->

<!--  SIDEBAR-AREA -->
  <div class="column-25">
      <!--  SIDEBAR --> 
        <div class="sidebar">
           <div class="sidebar-widget">
            <img src="assets/image/Banner-ads-1.gif">   
          </div>
       </div>
     </div>
   </div>
</div><!-- section-2 -->
</div>    
   
	  <div class="section-3">
      <span class="national">National</span>
         <div class="row">
           <?php while($row = mysqli_fetch_assoc($nationalNews)) { ?>
            <div class="column-20">
            <div class="news">
            <a href="single.php?pid=<?php echo $row['post_id']; ?>">
            <div class="news-image" style="background-image: url('admin/uploads/image/<?php echo $row['image'];?>')"></div>
            <h3><?php echo $row['title']; ?></h3>
          </a>
        </div><!-- news  -->    
      </div><!-- column-20 -->
    <?php } ?>  
   </div><!-- row -->
 </div><!-- section-1 -->

  <div class="section-4">
  	<div class="content ptb-25">
     <span class="international">International</span>      
       <div class="row">
        <?php while($row = mysqli_fetch_assoc($internationalNews)){?>
          <div class="column-20">
          <div class="news">
          <a href="single.php?pid=<?php echo $row['post_id']; ?>">
          <div class="news-image" style="background-image: url('admin/uploads/image/<?php echo $row['image'];?>')"></div>
          <h3><?php echo $row['title']; ?></h3>
        </a>
      </div><!-- news  -->    
     </div><!-- column-20 -->
    <?php } ?> 
  </div><!-- row -->
 </div><!-- ptb-25 -->
</div><!-- section-4 -->


<div class="section-5">
   <div class="ptb-25">
    <div class="row">
       <div class="column-75">
         <div class="row">
            <div class="column-41">       
            <!--Custom Tabs -->
              <ul class="tab-navigation">
                <li>All</li>
                <li>News</li>
                <li>Sports</li>
             </ul>
           <div class="tab-container-area">
            <div class="tab-container">
                <h1>১</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleGoodNews1)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>২</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleGoodNews2)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>৩</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleGoodNews3)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>৪</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleGoodNews4)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>৫</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleGoodNews5)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
            </div>
            <div class="tab-container">
                <h1>১</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleReadNews1)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>২</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleReadNews2)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>৩</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleReadNews3)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>৪</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleReadNews4)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>৫</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleReadNews5)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
            </div>
            <div class="tab-container">
                <h1>১</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleFeaturedNews1)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>২</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleFeaturedNews2)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>৩</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleFeaturedNews3)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>৪</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleFeaturedNews4)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
                <h1>৫</h1>
                 <?php while($row = mysqli_fetch_assoc($TabTitleFeaturedNews5)){?>
                <p class="tab-p"><a href=""><?php echo $row['title']; ?></a></p>
                <?php } ?>
             </div>
            </div>       
    <!-- Tabs -->
    </div>

        <div class="column-59">
            <ul class="tab-navigation-1">
                <li><img src="assets/image/katun.jpg" width="140px"></li>
             </ul>
             <div class="main-headline-2">
                <a href=""><img src="assets/image/banner-2.jpg"></a> 
             </div>
       </div>       
  </div>
</div>
            
    <div class="column-25">
         <div class="sidebar"><!--  SIDEBAR --> 
                      <ul class="tab-navigation-2">
                      <li></li>
                      </ul>
                      <div class="sidebar-ad2">
                      <a href="#">
                        <img src="assets/image/Banner-ads-1.gif">
                      </a>
                      </div>

                      <div class="column-40">
                      <a href="">
                      <div class="sidebar-news-image" style="background-image: url('assets/image/news/1.jpg')"></div></a>
                      </div>
                      <div class="column-60">
                      <div class="sidebar-news-data">
                      <a href="#">
                      <h2>Contrary to popular belief</h2>
                      <p>Contrary to popular belief Lorem Ipsum is not simply random text  </p></a>
                  </div>
                </div>
             </div>
           </div>
         </div>
       </div>
  </div><!-- section-5 -->


<div class="section-6">
      <div class="ptb-25">
       <div class="row head-news">
         <div class="column-50">
            <a href="">
                <div class="main-headline" style="background-image: url('assets/image/banner-2.jpg')">
                <div class="headline">Contrary to popular belief</div>
                
            </div>
            </a>
        </div>
        <div class="column-50">
            <div class="side-headline">

               <!--  SIDE NEWS-1 -->
                <div class="side-news">
                    <div class="row">
                        <div class="column-40">
                            <a href="">
                            <div class="side-news-image" style="background-image: url('assets/image/news/1.jpg')"></div></a>
                            </div>
                        <div class="column-60">
                            <div class="side-news-data">
                                <a href="#">
                                <h3>Contrary to popular belief</h3>
                                <p>Contrary to popular belief Lorem Ipsum is not simply random text Contrary to popular belief Lorem Ipsum is not simply random text </p></a>
                            </div>
                        </div>
                    </div>
                </div>

                <!--  SIDE NEWS-2 -->
                <div class="side-news">
                    <div class="row">
                        <div class="column-40">
                            <div class="side-news-image" style="background-image: url('assets/image/news/2.jpg')"></div>
                        </div>
                        <div class="column-60">
                            <div class="side-news-data">
                                <h3><a href="#">Lorem Ipsum is not simply</a></h3>
                                <p>Contrary to popular belief Lorem Ipsum is not simply random text Contrary to popular belief Lorem Ipsum is not simply random text </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!--  SIDE NEWS-3 -->
                <div class="side-news">
                    <div class="row">
                      <div class="column-40">
                        <div class="side-news-image" style="background-image: url('assets/image/news/3.jpg')"></div>
                        </div>
                        <div class="column-60">
                        <div class="side-news-data">
                          <h3><a href="#">Simply random text Contrary</a></h3>
                          <p>Contrary to popular belief Lorem Ipsum is not simply random text Contrary to popular belief Lorem Ipsum is not simply random text </p>
                        </div>
                      </div>
                    </div>
                 </div>
              </div>
           </div> 
        </div>   
     </div>
  </div>
</div><!-- container -->

<?php include("footer.php"); ?>
