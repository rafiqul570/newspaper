<?php 
 include("inc/query-code.php");
 include("header.php");
 ?>
<!-- main content section-->
<div id="single">
<div class="container">
  <div class="row mt-5">
    <?php
      $all_single = $newspaper->getSingleData($post_id);
      if($all_single){
       while($row = mysqli_fetch_assoc($all_single)) { 
      ?>
    <div class="col-md-9 single-9">
        <div class="category-name">
        <h4><span class="cat-name"><a href="categories.php?cid=<?php echo $row['category']?>"><?php echo $row['cat_name']?></a></span></h4>
        <h2><?php echo $row['title'];?></h2>
        <h4>রফিকুল ইসলাম</h4>
        <h4><?php echo $row['date'];?></h4>
        </div>
      
      <div class="row my-5 text-center">
        <div class="col-md-12">
          <div class="headline">
            <img src="admin/uploads/image/<?php echo $row['image'];?>" alt="">
            <h4><?php echo nl2br(html_entity_decode($row['description'])); ?></h4>
         </div>
        </div>
      </div>
   
<!-- Sub-category menu -->

  <div class="container">
    <?php
      $all_single = $newspaper->getSingleData($post_id);
      if($all_single){
       while($row = mysqli_fetch_assoc($all_single)) {
       ?>
       
       <!--  থেকে আরো পড়ুন -->
         <div class="col-md-12 category-name">
          <h5><span class="cat-name"><a href="categories.php?cid=<?php echo $row['category']?>"><?php echo $row['cat_name']?></a></span> <span class="cat-name2">থেকে আরো পড়ুন</span></h5>
       </div>

       <nav class="navbar navbar-expand-lg navbar-light bg-white">
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <?php
                  $sub_cat_id = $_GET['scid'];
                  $active ='';
                  $all_sub_cat= $newspaper->getSubCategoryData();
                  if($all_sub_cat){  
                  while($data = mysqli_fetch_assoc($all_sub_cat)){ 
      
                  if(isset($_GET['scid'])) {
                  if($data['scid'] == $sub_cat_id) {
                         $active = 'active';
                     }else{
                         $active =''; 
                     }   
                  }
                    
                  echo "<li class='nav-item'><a class='$active nav-link' href='sub-categories.php?scid={$data['sub_cat_id']}'>{$data['sub_cat_name']}</a></li>";
                
                }

               }
              ?>
              </ul>
            </div>
           </nav>
          </div>
          <div class="row">
            
          </div>
       </div>

    <div class="col-md-3">
      <p class="text-center">বিজ্ঞাপন</p>
      <img class="mb-5" src="assets/image/Banner-ads-1.gif" alt="image">
       </div> 
      </div>
      
      <div class="row">
        <div class="col-md-9"></div>
      <!--Related post section-->
          <div class="col-md-3">
          <h5 class="text-center">Related post</h5>
          <?php 
            $related_post = $newspaper->relatedPost($row['category']);
             if($related_post){
             while($row = mysqli_fetch_assoc($related_post)) {
            ?>
          
            <div class="row related-post">
              <div class="col-md-12 pt-5">
              <div class="single-side-news-title">
             <a href="single.php?pid=<?php echo $row['post_id']?>">
              <h6><?php echo $row['title'];?></h6>
             </a>
            </div>
            </div>
             <div class="col-md-4 single-side-news-image">
                <a href="single.php?pid=<?php echo $row['post_id']?>">
                <img src="admin/uploads/image/<?php echo $row['image'];?>" alt="">
             </div>
             <div class="col-md-8 col-sm-12">
              <div class="single-side-news-data">
                <p><?php echo substr($row['description'],0, 220); ?>...</p>
              </div> 
             </div>
            </div>
           <?php } } ?>
          </div>
        </div>
      <?php } } ?>
     <?php } } ?>
    </div>

<?php include("footer.php"); ?>