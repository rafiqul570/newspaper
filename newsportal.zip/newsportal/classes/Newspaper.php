<?php
spl_autoload_register(function($class_name){
include "classes/".$class_name.".php";
}); 
//error_reporting(0);  

/*
class
*/

class Newspaper{
  
  private $db;

  public function __construct(){
    $this->db = new Database();
  }

//===================Category PART===================//

   public function insertCategory($data){
            $cat_name  = $data['cat_name'];
            
       if ($cat_name == "" ) {
            
      $msg = '<div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
               <strong>Error !</strong> Field must not be Empty !
              </div>';
      
           return $msg; 
       
     }


    $query = "INSERT INTO category(cat_name)VALUES('$cat_name');";
    $result = $this->db->insert($query);

    if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong> Data Not Inserted.
            </div>';
  
       return $msg; 
       } 
}
    
//data query
    public function getAllCategoryData(){
        $query = "SELECT *FROM category ORDER BY cat_name DESC";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

        
      
//data query in menubar
      public function getCategoryData(){
        $query = "SELECT *FROM category WHERE post > 0  ORDER BY cat_id DESC";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }


//============Sub Category===========================//

    //===================Category PART===================//

   public function insertSubCategory($data){
            $category  = $data['category'];
            $sub_cat_name  = $data['sub_cat_name'];
            
            
       if ($category == "" || $sub_cat_name == "") {
            
      $msg = '<div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
               <strong>Error !</strong> Field must not be Empty !
              </div>';
      
           return $msg; 
       
     }


    $query = "INSERT INTO sub_category (category,sub_cat_name)VALUES('$category','$sub_cat_name');";
    $result = $this->db->insert($query);

    if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong> Data Not Inserted.
            </div>';
  
       return $msg; 
       } 
}
    
//Data Query
    public function getAllSubCategoryData(){
        $query = "SELECT *FROM sub_category ORDER BY sub_cat_name DESC";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }
      
//data query in sub menubar
      public function getSubCategoryData(){
        $query = "SELECT *FROM sub_category ORDER BY sub_cat_id DESC";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }



//=================Post News PART===================//

//Insert news

 public function insertNews($data){
    $title = $data['title'];
    $description = $data['description'];
    $category = $data['category'];
    $sub_category = $data['sub_category'];
    $date = date('l, d F Y ');
    //$author = $_SESSION['user_id'];
    
    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $tmp_name  = $_FILES['image']['tmp_name'];
    $permited  = array('jpeg', 'jpg', 'png', 'gif');
    $div = explode(".", $file_name);
    $file_ext = strtolower(end($div));
    $file_check = in_array($file_ext, $permited);
    $image = uniqid().$file_ext;
    $uploaded_image = '../uploads/image/'.$image;
            
  if ($title == "" || $description == "" || $category == "" || $sub_category == "" || $date == "" || $image == "") {
        
      $msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                  <span class='badge badge-pill badge-success'> Error !</span> Field must not be Empty!
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                      <span aria-hidden='true'>&times;</span>
                  </button>
              </div>";
    
         return $msg; 
   
 } 

  if ($file_check === false) {
      $msg = '<div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Sorry !</strong>You can upload only  -  ( jpeg, jpg, png, gif )
            </div>';
  
      return $msg;  
    
    }else{
    
   move_uploaded_file($tmp_name, $uploaded_image);

   $conn = mysqli_connect('localhost','root','','newspaper');
   $sql = "INSERT INTO post(title,description,category,sub_category,date,image)VALUES('$title','$description','$category','$sub_category','$date','$image');";

   $sql .= "UPDATE category SET post = post + 1 WHERE cat_id = '$category'";
    
   $result = mysqli_multi_query($conn,$sql);

   if($result) {
    
    header("Location:all-post.php? success= 1");
    
    }else{
      
    header("Location:add-post.php? error = 1");

    }

  }
 
    
}

   
//All News
    public function getAllNewsData(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        ORDER BY post.post_id DESC";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

//All News(Index page)
    public function getAllNewsData1(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        ORDER BY post.post_id DESC LIMIT 4";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

    public function getAllNewsData2(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        ORDER BY post.post_id DESC LIMIT 4,4";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        } 

   

    public function getNationalNewsData(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 17 ORDER BY post.post_id DESC LIMIT 5";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }


    public function getInternationalNewsData(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 16 ORDER BY post.post_id DESC LIMIT 5";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

//Tab title Good news
    public function getTabTitleGoodNews1(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category =17 ORDER BY post.post_id DESC LIMIT 1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

    public function getTabTitleGoodNews2(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 17 ORDER BY post.post_id DESC LIMIT 1,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

     public function getTabTitleGoodNews3(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 17 ORDER BY post.post_id DESC LIMIT 2,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

    public function getTabTitleGoodNews4(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 17 ORDER BY post.post_id DESC LIMIT 3,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

    public function getTabTitleGoodNews5(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 17 ORDER BY post.post_id DESC LIMIT 4,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }


//Tab title Read news
    public function getTabTitleReadNews1(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 16 ORDER BY post.post_id DESC LIMIT 1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

    public function getTabTitleReadNews2(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 16 ORDER BY post.post_id DESC LIMIT 1,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

     public function getTabTitleReadNews3(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 16 ORDER BY post.post_id DESC LIMIT 2,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

    public function getTabTitleReadNews4(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 16 ORDER BY post.post_id DESC LIMIT 3,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

    public function getTabTitleReadNews5(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 16 ORDER BY post.post_id DESC LIMIT 4,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }



//Tab title Featured  news
    public function getTabTitleFeaturedNews1(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 17 ORDER BY post.post_id DESC LIMIT 1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

    public function getTabTitleFeaturedNews2(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 17 ORDER BY post.post_id DESC LIMIT 1,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

     public function getTabTitleFeaturedNews3(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 17 ORDER BY post.post_id DESC LIMIT 2,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

    public function getTabTitleFeaturedNews4(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 17 ORDER BY post.post_id DESC LIMIT 3,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

    public function getTabTitleFeaturedNews5(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 17 ORDER BY post.post_id DESC LIMIT 4,1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }


     public function getKatunNews(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 16 ORDER BY post.post_id DESC LIMIT 1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }


     public function lastNews(){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id
        WHERE post.category = 20 ORDER BY post.post_id DESC LIMIT 1";
        $result = $this->db->select($query);
        if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }


//Single page select query
    public function getSingleData($post_id){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id 
        WHERE post.post_id = '$post_id' ";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }


//Categories page setup
     public function relatedPost($id){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_id,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id 
        WHERE post.category = '$id' ORDER BY post.post_id DESC LIMIT 1,4 ";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
           } else {
             return false;
          } 
        }

    public function relatedPost1($id){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_id,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id 
        WHERE post.category = '$id' ORDER BY post.post_id DESC LIMIT 5,4 ";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
           } else {
             return false;
          } 
        }


//Categories page setup
     public function getCategoriesData($cat_id){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id 
        WHERE post.category = '$cat_id' ORDER BY post.post_id DESC LIMIT 4,10 ";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
           } else {
             return false;
          } 
        }


         public function getCategoriesData1($cat_id){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id 
        WHERE post.category = '$cat_id' ORDER BY post.post_id DESC LIMIT 1";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
           } else {
             return false;
          } 
        }

         public function getCategoriesData2($cat_id){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id 
        WHERE post.category = '$cat_id' ORDER BY post.post_id DESC LIMIT 1,3";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
           } else {
             return false;
          } 
        }

         public function getCategoriesData3($cat_id){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id 
        WHERE post.category = '$cat_id' ORDER BY post.post_id DESC LIMIT 4,3";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
           } else {
             return false;
          } 
        }

      public function getCategoriesData4($cat_id){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.date,post.author,post.image,category.cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN user ON post.author = user.user_id 
        WHERE post.category = '$cat_id' ORDER BY post.post_id DESC LIMIT 7,10";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
           } else {
             return false;
          } 
        }

// sub-category
     public function getSubcategoriesData($sub_cat_id){
        $query = "SELECT post.post_id,post.title,post.description,post.category,post.sub_category,post.date,post.author,post.image,category.cat_name,sub_category.sub_cat_name,user.username FROM post
        LEFT JOIN category ON post.category = category.cat_id 
        LEFT JOIN sub_category ON post.sub_category = sub_category.sub_cat_id 
        LEFT JOIN user ON post.author = user.user_id 
        WHERE post.sub_category = '$sub_cat_id' ORDER BY post.post_id DESC LIMIT 5";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
           } else {
             return false;
          } 
        }

  }
  
?>

<?php 
//WHERE post.author = {$_SESSION['user_id']}

?>