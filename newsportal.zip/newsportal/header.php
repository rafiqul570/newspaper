<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>NEWSPAPER</title>
    <meta name="description" content="HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="assets/lib/bootstrap/assets/bootstrap.min.css" rel="stylesheet">
    <link href="assets/lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="assets/lib/Ionicons/css/ionicons.css" rel="stylesheet">
    <link href="assets/lib/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet">
    <link href="assets/lib/rickshaw/rickshaw.min.css" rel="stylesheet">

    <!-- CSS -->
  
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/modal.css"> 
    <link rel="stylesheet" href="css/category.css">
     <link rel="stylesheet" href="css/custom.css"> 
  
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'> 
<style>
 /* Single page css */
  #single a, p, h1, h2, h3, h4, h5, h6{{
    text-decoration: none;
    font-family: 'Nikosh BAN';
  }
  #single .single-side-news-image img{
    width: 100%;
    height: 100px;
    position: absolute;
    left: 0;
    padding-bottom: 20px;

  }

  #single .single-side-news-data a:hover{
    color: #000;
  }
  .related-post-2 .navbar .bg-white{
    background: white ;
  }

  @media screen and (max-width: 678px){
    #single .col-md-3 .single-side-news-image img{
      width: 100%;
      height: 200px;
    }
  }


 /*  Category page css */
 #categories a, p, h1, h2, h3, h4, h5, h6{
  text-decoration: none;
 }

 #categories a, p, h1, h2, h3, h4, h5, h6{
  text-decoration: none;
  font-family: 'Nikosh BAN'; 
 }
 #categories a:hover{
   color: #000;
 }
 .section-1 .row-sec-1{
  margin-top: 25px;
 }
 .section-1 .category-headline-image img{
  width: 100%;
  height: 400px;
 }

 .section-1 .category-headline-title{
  padding-top: 15px;
  font-size: 20px;
 }

 .section-1 .category-side-news-image img{
    width: 100%;
    height: 150px;
    padding-bottom: 25px;
 }

 .section-1 .category-side-news-data{
    width: 100%;
    height: 150px;
 }

 .section-2 .category-side-news img{
    width: 100%;
    height: 250px;
    padding-bottom: 25px;
 }

 .section-3 .category-side-news-image img{
    width: 100%;
    height: 200px;
    padding-bottom: 25px;
 }

 .sub-menu .sub-menubar:hover{
  text-decoration: none;
 }


</style>
</head>
<body>

 <!-- Header-Area -->
  <header><!-- header --> 
    <div class="header-top"><!-- header-top -->
        <div class="container"><!-- container -->
            <div class="row"><!-- row -->
                <!-- The Modal -->
                <div id="myModal" class="modal">
                  <span class="close">&times;</span>
                   <div class="navbar">
                       <a class="nav" href="">Home</a>
                       <a class="nav" href="">Service</a>
                       <a class="nav" href="">About</a>
                       <a class="nav" href="">Contact</a>
                       <a class="nav" href="">Html</a>
                       <a class="nav" href="">Css</a>
                       <a class="nav" href="">Java</a>
                   </div>
                </div>

                <div class="column-20"><!-- column-20 -->
                <div class="nav-icon">
                  <a id="myImg" href="#"><i class="fa fa-bars"></i></a> 
                  <a class="search" href="#"><i class="fa fa-search"></i></a>
                </div>
                    
            <!-- DATE  -->
            <div class="date"> 
             <?php 
              $currentDate = date("l, F j, Y");
              $engDATE = array('1','2','3','4','5','6','7','8','9','0','January','February','March','April','May','June','July','August','September','October','November','December',
                  'Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday');

              $bangDATE = array('১','২','৩','৪','৫','৬','৭','৮','৯','০',
                  'জানুয়ারী','ফেব্রুয়ারী','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট',
                  'সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর',

                  'শনিবার','রবিবার','সোমবার','মঙ্গলবার','বুধবার','বৃহস্পতিবার','শুক্রবার');
              $convertedDATE = str_replace($engDATE, $bangDATE, $currentDate);
              echo "$convertedDATE";
              ?>
           
            </div>
           </div>
                

                <div class="column-59"><!-- column-59 -->
                    <div class="logo">
                        <a href="index.php"><img src="assets/image/logo.png" alt="ribd" class="responsive-image"></a>
                    </div>
                </div><!-- column-59 -->
                
                <div class="column-20"><!-- column-20 -->
                  <div class="media-top">
                    <a href="http://www.facebook.com"><i class="fa fa-facebook tx-20"></i></a>
                    <a href="http://www.twitter.com"><i class="fa fa-twitter tx-20"></i></a>
                    <a href=""><i class="fa fa-share tx-20"></i></a>
                    <a href=""><i class="fa fa-bookmark tx-20"></i></a>
                  </div>
                    <!-- <ul class="nav-langu">
                    <div id="google_translate_element"></div>
                    <script type="text/javascript">
                     function googleTranslateElementInit() {
                     new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
                      }
                    </script>

                    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                   </ul> -->
                </div><!-- column-20  --> 
            </div><!-- row -->  
        </div><!-- container -->
    </div><!-- header-top -->


<!--  Navigation -->
   <nav class="navigation"><!--  Navigation Start-->
    <div class="container">
     <ul>
       <?php 
       $active = "";
       $all_cat = $newspaper->getCategoryData();
       if($all_cat){
       while($data = mysqli_fetch_assoc($all_cat)){ 
    
            if(isset($_GET['cid'])) {
            if($data['cat_id'] == $cat_id) {
                   $active = 'active';
               }else{
                   $active =''; 
               }   
            }
        
       echo "<li><a class='$active' href='categories.php?cid={$data['cat_id']}'>{$data['cat_name']}</a></li>";
        
        }
      }
      ?>
    </ul>
  </div>
 </nav><!--  Navigation End-->

  <div class="breaking-news"><!--  Breaking News Start-->
      <div class="container">
          <div class="row">
              <div class="column-20">
                 <div class="container">
                  <div class="update-left">ব্রেকিং নিউজ</div>
                  </div>
                </div>
                <div class="column-80">
                  <div class="update-right">
                  <marquee onmouseover="this.stop()" onmouseout="this.start()">
                  <?php
                  $allNews = $newspaper->getAllNewsData();
                  if($allNews){
                   while($row = mysqli_fetch_assoc($allNews)) { ?>
                    <a href="single.php?pid=<?php echo $row['post_id']?>">
                      <img src="admin/uploads/image/<?php echo $row['image'];?>" alt="">
                      <?php echo $row['title']; ?>
                    </a>
                    <?php } } ?>
                    </marquee> 
                    </div>
                </div>
            </div>
        </div>
   </div><!--  Breaking News End-->
</header><!-- header End --> 
