<?php
   include_once("../classes/Session.php");
   Session::init();
   if (isset($_GET['action']) && $_GET['action'] == "logout") {
   Session::destroy();
}


if (! isset($_SESSION['destroy'])){
   header ('Location:login.php');
  }

?>