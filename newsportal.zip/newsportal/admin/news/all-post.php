<?php
  spl_autoload_register(function($class_name){
   include "../../classes/".$class_name.".php";
});

// error_reporting(0);
  
$newspaper = new Newspaper();

?>


<?php include("../header.php"); ?>


    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">

      <div class="sl-pagebody">
      <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">All News</h6>
      
      <?php if(isset($_GET['success'])) {?>
      <div class="alert alert-success" align="left">
      <strong>Success !</strong> Data insert successfully.
      </div>
      <?php } ?>

        <div class="row row-sm mg-t-20">
          <div class="col-xl-12 mg-t-25 mg-xl-t-0">
            <div class="card pd-20 pd-sm-40 form-layout form-layout-5">
              <div><a class="btn btn-success float-right" href="add-post.php">Add</a></div>
              <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10"></h6>
              
              <div class="table-wrapper">
            <table id="datatable1" class="table datatables-responsive">
              <thead>
                <tr>
                  <th class="wd-10p">Serial No</th>
                  <th class="wd-30p text-center">Title</th>
                  <th class="wd-15p">Category</th>
                  <th class="wd-15p">Date</th>
                  <th class="wd-15p">Image</th>
                  <th class="wd-15p">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                  $newspaper = new Newspaper();
                  $allNews = $newspaper->getAllNewsData();
                  if ($allNews) {
                    $i = 0;
                    foreach ( $allNews as $row) {
                    $i++;
                          
                  ?> 
                <tr>
                  <td><?php echo $i; ?></td>
                  <td><?php echo $row['title']; ?></td>
                  <td><?php echo $row['cat_name']; ?></td>
                  <td><?php echo $row['date']; ?></td>
                  <td> <img style="width: 100px"; src="../uploads/image/<?php echo $row['image']?>"></td>
                  <td align="center">
                   <a class="btn btn-info btn-sm" href="update.php?id=
                    <?php echo $row ['post_id']; ?>">Edit</a>
                    <a class="btn btn-danger btn-sm" onclick="return confirm('Are you sure ?')"href="delete-post.php?id=<?php echo $row['post_id'] ?>&catid=<?php echo $row['category'] ?>">Delete</a>
                  </td>
                </tr>
                <?php } }?>
              </tbody>
            </table>
          </div><!-- table-wrapper -->
            
          </div><!-- card -->
        </div><!-- col-6 -->
      </div><!-- row -->
  </div><!-- sl-mainpanel -->
  <!-- ########## END: MAIN PANEL ########## -->
    
  <?php include("../footer.php") ?>        
    
    