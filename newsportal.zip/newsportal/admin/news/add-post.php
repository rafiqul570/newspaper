<?php
  spl_autoload_register(function($class_name){
   include "../../classes/".$class_name.".php";
});

//error_reporting(0);
  
$newspaper = new Newspaper();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $insNews = $newspaper->insertNews($_POST);
}


?>


<?php include("../header.php"); ?>

   <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
      <?php
        if (isset($insNews)) {
           echo $insNews;
          }
        ?>
      
      <div class="sl-pagebody">
        <div class="row row-sm mg-t-20">
          <div class="col-xl-12 mg-t-25 mg-xl-t-0">
            <div class="card pd-20 pd-sm-40 form-layout form-layout-5">
              <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Add News</h6>
            
          <form action="" method="POST" enctype="multipart/form-data"> 
            
            <div class="form-group">
              <label for="title">Add title</label>
                <input type="text" class="form-control" id="title" name="title" placeholder="Add title here">
            </div>
            
            <div class="form-group">
              <label for="description">Add description</label>
                <textarea name="description" id="summernote" rows="" cols=""></textarea>
              </div>
            
            <div class="form-group">
              <label for="category">Category name</label>
                <select class="form-control" name="category" id="category">
               <option disabled selected>Choose Category</option>
               <?php
                  $category = $newspaper->getAllCategoryData();
                    foreach ( $category as $data) {     
                 ?>
                <option value="<?php echo $data['cat_id'];?>"><?php echo $data['cat_name']; ?></option>
                <?php
                }
                ?>
              </select>
            </div>

            <div class="form-group">
              <label for="category">Sub Category name</label>
                <select class="form-control" name="sub_category" id="subcategory">
               <option disabled selected>Choose Category</option>
               <option value="0">None</option>
               <?php
                  $subcategory = $newspaper->getAllSubCategoryData();
                    foreach ( $subcategory as $data) {     
                 ?>
                <option value="<?php echo $data['sub_cat_id'];?>"><?php echo $data['sub_cat_name']; ?></option>
                <?php
                }
                ?>
              </select>
            </div>
      
            <div class="form-group">
              <label for="image">Featured Image</label>
                <input type="file" class="form-control" id="image" name="image">
              </div>

            <div class="form-group">
              <label for="date">Date</label>
                <input type="date" class="form-control" id="date" name="date" placeholder="Date">
              </div>
           
             <div class="form-layout-footer mg-t-30">
              <button type="submit" class="btn btn-info mg-r-5" name="submit" style="cursor: pointer;">Submit</button>
              <button class="btn btn-secondary" style="cursor: pointer;">Cancel</button>
              </div><!-- form-layout-footer -->
          </form>
            
            </div><!-- card -->
          </div><!-- col-6 -->
        </div><!-- row -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->

    <?php include("../footer.php"); ?>

    