<?php
$post_id = $_GET['id'];
$cat_id = $_GET['catid'];

$conn = mysqli_connect('localhost','root','','newspaper');
$query = "DELETE FROM post WHERE post_id = {$post_id};";
$query .= "UPDATE category SET post = post - 1 WHERE cat_id = {$cat_id}";

if(mysqli_multi_query($conn,$query)) {
header ('Location:all-post.php');

} else {

	echo "NOT DELETED";
}
