<?php
  spl_autoload_register(function($class_name){
   include "../../classes/".$class_name.".php";
});

error_reporting(0);
  
$newspaper = new Newspaper();


  
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $insertSubCat = $newspaper->insertSubCategory($_POST);
}

?>
<?php include("../header.php"); ?>
    
    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
      <?php
        if (isset($insertSubCat)) {
          echo $insertSubCat;
        }

        ?>
      <div class="sl-pagebody"> 
        <div class="sl-page-title">
          <h5>Sub Category</h5>
        </div><!-- sl-page-title -->

        <div class="row row-sm mg-t-20">
          <div class="col-xl-8">
            <div class="card pd-20 pd-sm-40 form-layout form-layout-4">
              <h6 class="card-body-title">All Sub Category</h6>

              <div class="table-responsive">
                <table class="table table-hover table-bordered table-primary mg-b-0">
                  <thead>
                    <tr>
                      <th>Serial No</th>
                      <th>Sub Category</th>
                      <th>Category</th>
                      <th>Post</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                   <?php
                      $newspaper = new Newspaper();
                      $sub_category = $newspaper->getAllSubCategoryData();
                      if ($sub_category) {
                        $i = 0;
                        foreach ( $sub_category as $data) {
                        $i++;
                          
                     ?>
                  <tr align="center">
                    <td><?php echo $i; ?></td>
                    <td><?php echo $data['sub_cat_name']; ?></td>
                    <td><?php echo $data['category']; ?></td>
                    <td><?php echo $data['post']; ?></td>
                    <td>
                     <a class="btn btn-info" href="update.php?id=
                      <?php echo $data ['sub_cat_id']; ?>">Edit</a>
                      <a class="btn btn-danger" onclick=
                      "return confirm('Are you sure ?')" href="delete.php
                      "?del=<?php echo $data ['sub_cat_id']; ?>">Delete</a>
                    </td>
                  </tr> 
                  <?php } }?>
                </tbody>
              </table>
            </div><!-- table-responsive -->
           </div><!-- card -->
         </div><!-- col-8 -->
          
<!-- ==================Add Category=================== -->
          
          <div class="col-xl-4 mg-t-25 mg-xl-t-0">
            <div class="card pd-20 pd-sm-40 form-layout form-layout-5">
              <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Add Sub-category</h6>


            <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
              <div class="form-group">
              <label for="category">Category name</label>
                <select class="form-control" name="category" id="category">
               <option disabled selected>Choose Category</option>
               <?php
                  $category = $newspaper->getAllCategoryData();
                    foreach ( $category as $data) {     
                 ?>
                <option value="<?php echo $data['cat_id'];?>"><?php echo $data['cat_name']; ?></option>
                <?php
                }
                ?>
              </select>
            </div>

              <div class="form-group">
                <label for="text">Sub-category name:</label>
                <input type="text" class="form-control" id="sub_cat_name" name="sub_cat_name" placeholder="Enter Sub category name">
              </div>

              <div class="form-layout-footer mg-t-30">
                <button type="submit" class="btn btn-info mg-r-5" name="submit" style="cursor: pointer;">Submit</button>
                <button class="btn btn-secondary" style="cursor: pointer;">Cancel</button>
              </div><!-- form-layout-footer -->
            </form>
            </div><!-- card -->
          </div><!-- col-6 -->
        </div><!-- row -->     
     
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->
    
    <?php include("../footer.php"); ?> 
