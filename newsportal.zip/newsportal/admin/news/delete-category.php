<?php 
include('../include/connect.php');
$post_id = $_GET['id'];
$cat_id = $_GET['catid'];

$con = connectDB();
$query = "DELETE FROM post WHERE post_id = {$post_id};";
$query .= "UPDATE category SET post = post - 1 WHERE cat_id = {$cat_id}";

if(mysqli_multi_query($con,$query)) {
header ('Location:all-news.php');

} else {

	echo "NOT DELETED";
}
?>