<?php
   spl_autoload_register(function($class_name){
   include "../classes/".$class_name.".php";
});

 $user = new User();

  if (isset($_GET['id'])) {
     $userid = (int)$_GET['id'];
  }
 
    
  if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['Login'])) {
      $userLogin = $user->userLogin($_POST);
  }

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Blog</title>

    <!-- vendor css -->
    <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="lib/Ionicons/css/ionicons.css" rel="stylesheet">


    <!-- Starlight CSS -->
    <link rel="stylesheet" href="css/starlight.css">
  </head>

  <body class="bg-dark">

    <div class="d-flex align-items-center justify-content-center bg-sl-primary ht-100v">
      <div class="login-content">

        <?php
        if (isset($userLogin)) {
          echo $userLogin;
        }

        ?>

      <div class="login-wrapper wd-300 wd-xs-400 pd-25 pd-xs-20 bg-white">
        <div class="signin-logo tx-center tx-24 tx-bold tx-inverse"><span class="tx-info tx-normal">Admin Login</span></div>
        <div class="tx-center mg-b-50"></div>
        <form action="" method="POST">
        <div class="form-group">
          <input type="email" class="form-control" name="email" placeholder="Enter your Email">
        </div><!-- form-group -->
        <div class="form-group">
          <input type="password" class="form-control" name="password" placeholder="Enter your password">
          <br>
          <div class="checkbox">
          <label>
          <input type="checkbox"> Agree the terms and policy
          </label>
          </div>
        </div><!-- form-group -->
        <button type="submit" class="btn btn-info btn-block" name="Login">Sign In</button>
        </form>
        <div class="mg-t-60 tx-center">Not yet a member? <a href="register.php" class="tx-info">Sign Up</a></div>
        
      </div><!-- login-wrapper -->
     </div>
    </div><!-- d-flex -->

    <script src="lib/jquery/jquery.js"></script>
    <script src="lib/popper.js/popper.js"></script>
    <script src="lib/bootstrap/bootstrap.js"></script>

  </body>
</html>
