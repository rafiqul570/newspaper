<?php 
include("inc/query-code.php");
include("header.php"); 
?>

<!-- ############ Main content ############## -->
<div id="categories">
<div class="section-1 my-4">
  <div class="container">
    <div class="row row-sec-1">
      <div class="col-md-6">

        <?php 
        $all_categories1 = $newspaper->getcategoriesData1($cat_id);
        if($all_categories1){
        while($row = mysqli_fetch_assoc($all_categories1)) { 

          ?>
            <a href="single.php?pid=<?php echo $row['post_id']?>">
              <div class="category-headline-image">
                 <img src="admin/uploads/image/<?php echo $row['image'];?>" alt="">
             </div></a>
             <div class="category-headline-title">
             <a href="single.php?pid=<?php echo $row['post_id']?>">
                <?php echo $row['title'];?> 
             </a>
            </div>
        <?php } }?>
      </div>
      <div class="col-md-6">
        <?php
        $all_categories2 = $newspaper->getcategoriesData2($cat_id);
        if($all_categories2){
        while($row = mysqli_fetch_assoc($all_categories2)) { 
        ?>
        <div class="row">
          <div class="col-md-5">
            <a href="single.php?pid=<?php echo $row['post_id']?>">
              <div class="category-side-news-image"> 
                <img src="admin/uploads/image/<?php echo $row['image'];?>" alt="">
              </div></a>
              </div>
          <div class="col-md-7">
            <div class="category-side-news-data">
               <a href="single.php?pid=<?php echo $row['post_id']?>">
               <h5><?php echo $row['title'];?></h5>
               <p><?php echo substr($row['description'],0,350); ?>...</p></a>
            </div>
          </div>
        </div>
        <?php } } ?>
      </div>
    </div>
  </div>
</div> 

<div class="section-2">
  <div class="container">
    <div class="row">
      <div class="col-md-9">

        <div class="row">
          <?php 
            $all_categories3 = $newspaper->getcategoriesData3($cat_id);
            if($all_categories3){
            while($row = mysqli_fetch_assoc($all_categories3)) { 
            ?>
            <div class="col-md-4 category-side-news">
            <a href="single.php?pid=<?php echo $row['post_id']?>"> 
              <img src="admin/uploads/image/<?php echo $row['image'];?>" alt="">
              <h5><?php echo $row['title'];?></h5>
              <p><?php echo substr($row['description'],0,350); ?>...</p>
            </a>
         </div>
         <?php } }?>
        </div>        
       </div>
      <div class="col-md-3">
        <img class="mb-5" src="assets/image/Banner-ads-1.gif" alt="image">
      </div>
    </div>
  </div>
</div> 

<section class="section-3">
  <div class="container">
    <div class="row">
      <div class="col-md-9">
        <div class="row">
          <div class="col-md-4"></div>
          <div class="col-md-8">
            <div class="row ">
              <?php 
                $all_categories4 = $newspaper->getcategoriesData4($cat_id);
                if($all_categories3){
                while($row = mysqli_fetch_assoc($all_categories4)) { 
                ?>
              <div class="col-md-8 category-side-news-data">
                <a href="single.php?pid=<?php echo $row['post_id']?>"> 
                  <h5><?php echo $row['title'];?></h5>
                  <p><?php echo substr($row['description'],0,450); ?>...</p>
                </a>
              </div>
              <div class="col-md-4 category-side-news-image">
                <a href="single.php?pid=<?php echo $row['post_id']?>"> 
                  <img src="admin/uploads/image/<?php echo $row['image'];?>" alt="">
                </a>
              </div>
            <?php } } ?>
            </div>
          </div>
        </div>  
      </div>
      <div class="col-md-3">
        <img class="mb-5" src="assets/image/Banner-ads-1.gif" alt="image">
      </div>
    </div>
  </div>
</section>
</div> 

<?php include("footer.php"); ?>