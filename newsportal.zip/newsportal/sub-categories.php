<?php 
include("inc/query-code.php");
include("header.php"); 
?>

<div class="container">
  <div class="row">
    <div class="col-md-12 text-center my-4">
      <img src="assets/image/ad1.png"> 
    </div>
  </div>
  <div class="row">
    <div class="col-md-4 text-right pb-4">
      <?php 
        $sub_categories = $newspaper->getSubcategoriesData($sub_cat_id);
        if($sub_categories){
        while($row = mysqli_fetch_assoc($sub_categories)) { 

          ?>
      <h2><?php echo $row['sub_cat_name']?></h2>

      <?php } } ?>
    </div>
    <div class="col-md-8">
      
    </div>
  </div>
</div>


<?php include("footer.php"); ?>