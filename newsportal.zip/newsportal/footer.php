<!-- Footer-Area -->
   
   <footer>
    <div class="ptb-25">
        <div class="row">
            <div class="column-30">
            <!-- Logo and Social -->
            <div class="footer-logo">
                <img src="assets/image/logo.PNG" alt="" class="responsive-image">
            </div>
              <ul class="footer-social">
                <li><a href=""><img src="assets/image/social/facebook.png" alt="facebook"></a></li>
                <li><a href=""><img src="assets/image/social/youtube.png" alt="youtube"></a></li>
                <li><a href=""><img src="assets/image/social/twitter.png" alt="twitter"></a></li>
                <li><a href=""><img src="assets/image/social/instagram.png" alt="instagram"></a></li>
              </ul>
              <address>
                  KACHUA, BAGERHAT, BANGLADESH - 9310 
              </address>  
            </div>
            <div class="column-20">
                <!-- Category -->
                <div class="sec-title">Category</div>
                   <ul class="footer-cat">
                       <li><a href="">National</a></li>
                       <li><a href="">International</a></li>
                       <li><a href="">Entertainment</a></li>
                       <li><a href="">Sports</a></li>
                       <li><a href="">Audio & Video</a></li>
                   </ul>   
              </div>
            <div class="column-20">
                <!-- Recent News -->
               <div class="sec-title">Recent News</div>
                   <ul class="footer-cat">
                       <li><a href="">Lorem Ipsum is not simply</a></li>
                       <li><a href="">Lorem Ipsum is not simply</a></li>
                       <li><a href="">Lorem Ipsum is not simply</a></li>
                       <li><a href="">Lorem Ipsum is not simply</a></li>
                       <li><a href="">Lorem Ipsum is not simply</a></li>
                   </ul> 
               </div>
            <div class="column-30">
            <!--  Photo Gallery -->
               <div class="sec-title">Photo Gallery</div>
                 <ul class="footer-gallery">
                    <li class="column-20"><img src="assets/image/news/1.jpg" alt="Image Not Found"></li>   
                    <li class="column-20"><img src="assets/image/news/2.jpg" alt="Image Not Found"></li>   
                    <li class="column-20"><img src="assets/image/news/3.jpg" alt="Image Not Found"></li>   
                    <li class="column-20"><img src="assets/image/news/4.jpg" alt="Image Not Found"></li>   
                    <li class="column-20"><img src="assets/image/news/1.jpg" alt="Image Not Found"></li>   
                    <li class="column-20"><img src="assets/image/news/2.jpg" alt="Image Not Found"></li>   
                    <li class="column-20"><img src="assets/image/news/3.jpg" alt="Image Not Found"></li>   
                    <li class="column-20"><img src="assets/image/news/4.jpg" alt="Image Not Found"></li>   
                    <li class="column-20"><img src="assets/image/news/1.jpg" alt="Image Not Found"></li>   
                    <li class="column-20"><img src="assets/image/news/2.jpg" alt="Image Not Found"></li>   
                 </ul>
              </div>
           </div>
        </div>

        <div class="footer-bottom">
            <h3>NEWS WEBSITE &Copy,2021 </h3>
            <a href="http://ribd.rf.gd/">ribd.rf.gd</a>     
        </div>
     </footer>


<!-- =====JQUERY==== -->
<script src="assets/lib/jquery/jquery.js"></script>
<script src="assets/lib/popper.js/popper.js"></script>
<script src="assets/lib/bootstrap/bootstrap.js"></script>
<script src="assets/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/lib/highlightjs/highlight.pack.js"></script>
<script src="assets/js/main.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

</body>
</html>